y0 = seq(-3,20)
y1 = seq(2,18,by=2)
y2 = rep(4,8)
y3 = seq(0,16,length.out = 8)

