
public class Equipement {

	private boolean interaction;
	
	public Equipement(){
		
	}
}
