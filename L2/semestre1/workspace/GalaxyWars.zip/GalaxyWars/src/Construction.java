
public class Construction {
	
	private Vaisseaux vaisseaux;
	
	public Construction(){}

}
