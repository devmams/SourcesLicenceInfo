
public class Noeud {

	private Region r0;
	private Noeud r1;
	private Noeud r2;
	private Noeud r3;
	private Noeud r4;
	
	public Noeud() {
	}

}
