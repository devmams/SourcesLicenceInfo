
public class QuadTree {

	private Noeud racine;
	
	public QuadTree(){
		
	}
}
