import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;



public class Terrain {

	private QuadTree qt;
	private ArrayList<Surface> surfaces;
	
	
	public Terrain(){}
	
	private void ajouterSurface(ArrayList<Double> coords,char couleur){
		Surface s = new Surface(coords,couleur);
		surfaces.add(s);
	}
	
	public void lireDescription(String chemin_fichier) throws IOException
	{
		int data,prevdata;
		InputStreamReader r = null;
		String buffer = "";
		boolean lecturePoint;
		r = new FileReader(chemin_fichier);
		
		data = r.read();
		
		while(data != -1 && (char) data != '\n')
		{
			buffer+=(char) data;
			data = r.read();
		}
		int nbSurfaces = Integer.parseInt(buffer);
		
		for(int i=0;i<nbSurfaces;i++){
			data = r.read();
			lecturePoint = false;
			ArrayList<Double> listeCoords= new ArrayList();
			while((char) data !='\n'){
				if((char) data =='('){
					lecturePoint = true;
					buffer = "";
				}
				if(lecturePoint && (char) data !=','){
					buffer+=(char) data;
				}
				else if(lecturePoint && (char) data == ','){
					listeCoords.add(Double.parseDouble(buffer));
					buffer = "";
				}
				else if(lecturePoint && (char) data == ')'){
					lecturePoint = false;
					listeCoords.add(Double.parseDouble(buffer));
				}
				prevdata = data;
				data = r.read();
				if((char) data == '\n')
				{
					ajouterSurface(listeCoords,(char) prevdata);
				}
				
			}
		}
		r.close();
	}

}
