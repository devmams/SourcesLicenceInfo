import java.util.ArrayList;


public class Region {

	private ArrayList<Triangle> triangles;
	public Region() {
		
	}

}
