import java.util.ArrayList;


public class Surface {

	private char couleur;
	private Polygone poly;
	
	public Surface(ArrayList<Double> coords,char couleur){
		ArrayList<Point> points = new ArrayList();
		Point p;
		for(int i=0;i<coords.size();i=i+2){
			p = new Point(coords.get(i),coords.get(i+1));
			points.add(p);
		}
		poly = new Polygone(points);
	}
}
