
public class Segment extends Droite {

	public Segment(Point A,Point B){
		super(A,B);
	}
	
	public boolean intersecte(Point A,Point B,Point C,Point D){
		Droite d1 = new Droite(A, B);
		Droite d2 = new Droite(C, D);
		boolean res = false;
		if(d1.intersecte(d2)){
			Point p = d1.pointIntersection(d2);
			if(appartient(p, A, B) && appartient(p, C, D))
				res = true;
		}
		return res;
	}
	
	public boolean appartient(Point p,Point A,Point B){
		boolean res = false;
		Droite d = new Droite(A, B);
		if(d.appartient(p) == 0){
			if((p.getY() <= max(A.getY(),B.getY())) && (p.getX() <= max(A.getX(),B.getX()))
			&& (p.getY() >= min(A.getY(),B.getY())) && (p.getX() >= min(A.getX(),B.getX())))
				res = true;
		}
		return res;
	}
	
	public Point intersectionSegment(Point A,Point B,Point C,Point D){
		Droite d1 = new Droite(A, B);
		Droite d2 = new Droite(C, D);
		Point p = d1.pointIntersection(d2);
		if(A == p)
			System.out.println("le point d'intersection est le point A");
		else if(B == p)
			System.out.println("le point d'intersection est le point B");
		else if(C == p)
			System.out.println("le point d'intersection est le point C");
		else if(D == p)
			System.out.println("le point d'intersection est le point D");
		else
			System.out.println("le point d'intersection n'est ni A ni B ni C ni D");
		return p;
	}
	
	private double max(double a,double b){
		double res = a;
		if(b > a)
			res = b;
		return res;
	}
	
	private double min(double a,double b){
		double res = a;
		if(a > b)
			res = b;
		return res;
	}
}
